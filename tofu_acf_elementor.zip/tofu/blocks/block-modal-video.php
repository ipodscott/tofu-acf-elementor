<div class="video-block">
	<?php $videoSource = block_field( 'video-source', false );?> 
	
	<?php if($videoSource == "youtube"){ ?>
			<div style="display: block; position: relative; margin: 0 auto;">
				<img style="width: 100%; height: auto; display: block; position: relative;" src="https://img.youtube.com/vi/<?php block_field('youtube-id');?>/maxresdefault.jpg"/>
				<iframe style="display: block; position: absolute; top: 0; left:0; width: 100%; height: 100%;" src="https://www.youtube.com/embed/<?php block_field('youtube-id');?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		

	<?php }else if ($videoSource == "external"){ ?>
		
		<video style="width: 100%; height: auto;" src="<?php block_field('video-url'); ?>" controls></video>
		
	<?php }else if ($videoSource == "upload"){ ?>
	
		<video style="width: 100%; height: auto;" src="<?php block_field('upload'); ?>" controls></video>
		
	<?php }else{ ?>
 
  <?php } ?>
		
	
</div>