<div style="display: block; position: relative; float: left; width: 100%; height: auto; clear: both;">
	<div class="half"><?php block_field( 'left-column' ); ?></div>
	<div class="half"><?php block_field( 'right-column' ); ?></div>	
</div>