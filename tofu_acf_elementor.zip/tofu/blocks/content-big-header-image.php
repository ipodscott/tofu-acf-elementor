<?php
/**
 * Block Name: Header
 *
 * This is the template that display a movies.
 */
// create id attribute for specific styling
$id = 'big-header-image-' . $block['id'];
?>

<div class="big-header fadey parallax" style="background-image: url(<?php the_field('background_image');?>);">
	<div class="header-title"><?php the_field('main_copy');?></div>
</div>

<?php
if (is_admin() && (  defined( 'DOING_AJAX' ) ||  DOING_AJAX ) ) {?>
    <style type="text/css"> </style>

<?php } ?>
