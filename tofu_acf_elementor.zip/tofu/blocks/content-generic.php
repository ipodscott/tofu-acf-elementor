<?php
/**
 * Block Name: Generic Block Name
 *
 * This is the ________ template to show _________.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'elementor-block-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'elementor-block-';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}

?>

<div class="<?php echo esc_attr($className); ?>" id="<?php echo esc_attr($id); ?>">


</div>


<?php if (is_admin() && (  defined( 'DOING_AJAX' ) ||  DOING_AJAX ) ) {?>

<?php } ?>
