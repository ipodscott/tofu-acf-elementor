<?php
/**
 * Block Name: Modal Movie
 *
 * This is the template that display a movies.
 */


// Create id attribute allowing for custom "anchor" value.
$id = 'modal-movie-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'modal-movie';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}

?>

<div class="<?php echo esc_attr($className); ?>" id="<?php echo esc_attr($id); ?>" style="padding: <?php the_field('padding_top');?>px 0 <?php the_field('padding_bottom');?>px 0;">
	
<?php $selectVideo = get_field('select_movie_format'); if($selectVideo == "remote_mp4"){ ?>
 <img class="modal-movie-thumb movie-btn <?php the_field('resolution');?>" vidUrl="<?php the_field('remote_mp4');?>" style="background-image: url(<?php the_field('thumbnail');?>);" src="<?php bloginfo('template_directory'); ?>/images/video_thumb.png"/>
<?php }else if ($selectVideo == "youtube"){ ?>
  <img class="modal-movie-thumb tube-link <?php the_field('resolution');?>" vidUrl="https://www.youtube.com/embed/<?php the_field('youtube_url');?>?autoplay=1" style="background-image: url(<?php the_field('thumbnail');?>);" src="<?php bloginfo('template_directory'); ?>/images/video_thumb.png"/>
<?php }else if ($selectVideo == "upload"){ ?>
  <img class="modal-movie-thumb movie-btn <?php the_field('resolution');?>" vidUrl="<?php the_field('mp4_upload');?>" style="background-image: url(<?php the_field('thumbnail');?>);" src="<?php bloginfo('template_directory'); ?>/images/video_thumb.png"/>
<?php }else if ($selectVideo == "vimeo"){ ?>
  <img class="modal-movie-thumb tube-link <?php the_field('resolution');?>" vidUrl="https://player.vimeo.com/video/<?php the_field('vimeo_url');?>?autoplay=1" style="background-image: url(<?php the_field('thumbnail');?>);" src="<?php bloginfo('template_directory'); ?>/images/video_thumb.png"/>

  
<?php }else{ ?>
  /*$first_condition and $second_condition are false*/
<?php } ?>
	
	
	<div class="modal-movie-title"><?php the_field('movie_title');?></div>
</div>


<?php
if (is_admin() && (  defined( 'DOING_AJAX' ) ||  DOING_AJAX ) ) {?>
   

<?php } ?>