<?php
/**
 * Block Name: Movie
 *
 * This is the template that display a movies.
 */


// Create id attribute allowing for custom "anchor" value.
$id = 'movie-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'movie';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}

?>


<div class="<?php echo esc_attr($className); ?>" id="<?php echo esc_attr($id); ?>" style="padding: <?php the_field('padding_top');?>px 0 <?php the_field('padding_bottom');?>px 0;">
<?php $selectMovie = get_field('select_movie'); if($selectMovie == "mp4"){ ?>
 <video class="mp4-video" src="<?php the_field('movie');?>" controls></video>
<?php }else if ($selectMovie == "youtube"){ ?>

<div style="display: block; position: relative; margin: 0 auto;">
<img style="width: 100%; height: auto; display: block; position: relative;" src="https://img.youtube.com/vi/<?php the_field('youtube_id');?>/maxresdefault.jpg"/>
<iframe style="display: block; position: absolute; top: 0; left:0; width: 100%; height: 100%;" src="https://www.youtube.com/embed/<?php the_field('youtube_id');?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

</div>

<?php }else if ($selectMovie == "upload"){ ?>
 <video class="mp4-video" src="<?php the_field('mp4_upload');?>" controls></video>
<?php }else{ ?>
  Please Select a Movie Type
<?php } ?>

</div>
<?php
if (is_admin() && (  defined( 'DOING_AJAX' ) ||  DOING_AJAX ) ) {?>
    <style type="text/css">
	.mp4-video {
		max-width: 100%;
    width: 100%;
    height: auto;
	}
</style>

<?php } ?>

