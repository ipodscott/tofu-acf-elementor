 
    <div class="open-overlay">
        <div class="open-overlay-box">
            <div class="open-overlay-logo"><img class="cover-title-image" src="<?php bloginfo('template_directory'); ?>/images/spinner.svg"></div>
        </div>
    </div>
    
<div class="modal-vid">
    <div class="movie-box">
        <div class="wide-screen">
            <div class="vid-holder">
                <div class="close" vidUrl="#">Close</div>
                <img class="widescreen-img" src="https://s3.amazonaws.com/imglibs/bg_widescreen.gif"/>
                <img class="standard-img" src="https://s3.amazonaws.com/imglibs/standard_bg.gif"/>
                <img class="sixteen-nine" src="https://s3.amazonaws.com/imglibs/16x9_bg.png"/>
                <img class="pal" src="https://s3.amazonaws.com/imglibs/pal.png"/>
               
                <video id="myVideo" class="myVideo hide" src="" controls></video>
                <iframe class="youTube hide" src="" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>
   
  

      <?php wp_footer(); ?>
      
      
      
         
     
</body>

</html>