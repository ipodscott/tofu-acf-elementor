<?php  function add_scipts() {
	
// Add Scripts
	if (!is_admin()) {
		wp_deregister_script( 'jquery' );
	
		wp_register_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js', '', true, '');
		wp_enqueue_script('jquery');
		wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts_min.js', array('jquery'), '1.0', true );
	}
}
add_action('init', 'add_scipts');


// Add Styles
function prefix_add_footer_styles() {
	wp_enqueue_style( 'googlefonts', '//fonts.googleapis.com/css?family=Material+Icons',true,'1.1','all');
    wp_enqueue_style( 'styles', get_template_directory_uri() . '/css/main_min.css',true,'1.1','all');
    wp_enqueue_style( 'mods', get_template_directory_uri() . '/css/mods.css',true,'1.1','all');

};
add_action( 'get_footer', 'prefix_add_footer_styles' );


// Remove WP Version From Styles	
add_filter( 'style_loader_src', 'sdt_remove_ver_css_js', 9999 );
// Remove WP Version From Scripts
add_filter( 'script_loader_src', 'sdt_remove_ver_css_js', 9999 );

// Function to remove version numbers
function sdt_remove_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}

//Register Menus

function register_my_menu() {
  register_nav_menu('main_menu',__( 'Main Menu' ));
}
add_action( 'init', 'register_my_menu' );

//Add Featured Image to Pages

 add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );

//Add SVG Mime Type

function cc_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');


//Create Gutenberg Block Categories

function my_custom_block_category( $categories, $post ) {
	return array_merge(
		$categories,
		array(
			array(
				'slug' => 'video-blocks',
				'title' => __( 'Video Blocks', 'video-blocks' ),
			),
		)
	);
	
}
add_filter( 'block_categories', 'my_custom_block_category', 10, 2);

function my_custom_header_category( $categories, $post ) {
	return array_merge(
		$categories,
		array(
			array(
				'slug' => 'header-blocks',
				'title' => __( 'Header Blocks', 'header-blocks' ),
			),
		)
	);
	
}
add_filter( 'block_categories', 'my_custom_header_category', 10, 2);


function my_custom_elementor_category( $categories, $post ) {
	return array_merge(
		$categories,
		array(
			array(
				'slug' => 'elementor-blocks',
				'title' => __( 'Elementor Blocks', 'elementor-blocks' ),
			),
		)
	);
	
}
add_filter( 'block_categories', 'my_custom_elementor_category', 10, 2);

//Add ACF Stuff

add_action('acf/init', 'my_acf_init');
function my_acf_init() {
	
	
	// check function exists
	if( function_exists('acf_register_block') ) {
		
		
		/*Register Movie Block*/
		
		acf_register_block(array(
			'name'				=> 'movie',
			'title'				=> __('Movie'),
			'description'		=> __('A custom movie block.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'video-blocks',
			'icon'				=> 'format-video',
			'keywords'			=> array( 'movie' ),
		));
		
		/*Register Modal Movie*/
		
		acf_register_block(array(
			'name'				=> 'modal-movie',
			'title'				=> __('Modal Movie'),
			'description'		=> __('A custom modal movie block.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'video-blocks',
			'icon'				=> 'playlist-video',
			'keywords'			=> array( 'movie' ),
		));
		
		
		/*Register Big Header Block*/
		
		acf_register_block(array(
			'name'				=> 'big-header-image',
			'title'				=> __('Big Header Image'),
			'description'		=> __('A large header image block.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'header-blocks',
			'icon'				=> 'format-image',
			'keywords'			=> array( 'header' ),
		));
		
		
		/*Elementor Block*/
		
		acf_register_block(array(
			'name'				=> 'elementor-block',
			'title'				=> __('Elementor Block'),
			'description'		=> __('A block to add Elementor Shortcode.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'elementor-blocks',
			'icon'				=> 'welcome-widgets-menus',
			'keywords'			=> array( 'elementor' ),
		));
		
		
		acf_register_block(array(
			'name'				=> 'custom-background',
			'title'				=> __('Elementor Custom Background Block'),
			'description'		=> __('A block to add Elementor Header with a Custom Background.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'elementor-blocks',
			'icon'				=> 'format-image',
			'keywords'			=> array( 'elementor' ),
		));
		
		acf_register_block(array(
			'name'				=> 'custom-video-background',
			'title'				=> __('Elementor Custom Video Background Block'),
			'description'		=> __('A block to add Elementor Header with a Custom Video.'),
			'render_callback'	=> 'my_acf_block_render_callback',
			'category'			=> 'elementor-blocks',
			'icon'				=> 'format-video',
			'keywords'			=> array( 'elementor' ),
		));
		
		
	}
}

// Add Custom Paths to ACF Gutenberg Blocks


function my_acf_block_render_callback( $block ) {
	
	$slug = str_replace('acf/', '', $block['name']);
	
	// include a template part from within the "template-parts/block" folder
	if( file_exists( get_theme_file_path("/blocks/content-{$slug}.php") ) ) {
		include( get_theme_file_path("/blocks/content-{$slug}.php") );
	}
}



// Custom CSS Styles

function custom_admin_js() {

    wp_enqueue_style( 'styles', get_template_directory_uri() . '/css/mods.css',true,'1.1','all');
    wp_enqueue_style( 'admin-fonts', 'https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i|Material+Icons',true,'1.1','all');
}
add_action('admin_footer', 'custom_admin_js');
