  <div class="menu-layer"></div>

 <i class="material-icons menu-btn">menu</i>
        
 <div class="menu shadow">
 	<div class="menu-title">Main Menu</div>
 	
 	<div class="main-menu">
	 	<?php wp_nav_menu( array( 'theme_location' => 'main_menu' ) ); ?>
	</div>
            
    <i class="material-icons close-menu">close</i></div>
            
        
</div>