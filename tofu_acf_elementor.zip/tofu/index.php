
  <?php get_header(); ?>
  
   <!-- open all --><div class="all" name="#top">
	

	   <?php if (have_posts()) : ?>
	   <?php while (have_posts()) : the_post(); ?>
	   <?php the_content(); ?>
	   <?php endwhile; ?>
	   <?php endif; ?>

  
        
        
       <?php include('includes/nav.php');?>    
<!-- close all --> </div>
   <?php get_footer(); ?>